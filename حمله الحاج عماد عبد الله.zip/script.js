// بسيط: سلايدر صور وزر الاتصال يعمل مباشرة
document.addEventListener('DOMContentLoaded', function(){
  const slides = document.querySelectorAll('.slides img');
  let idx = 0;
  const show = (i)=>{
    slides.forEach((s,si)=> s.classList.toggle('active', si===i));
  };
  show(idx);

  document.getElementById('next').addEventListener('click', function(){
    idx = (idx+1) % slides.length;
    show(idx);
  });
  document.getElementById('prev').addEventListener('click', function(){
    idx = (idx-1 + slides.length) % slides.length;
    show(idx);
  });

  // auto slide كل 6 ثواني
  setInterval(()=> {
    idx = (idx+1) % slides.length;
    show(idx);
  }, 6000);
});